import numpy as np
import pandas as pd
from freqtrade.strategy import IStrategy
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib
from datetime import datetime

class AlphaStrategy(IStrategy):
    INTERFACE_VERSION = 3
    # 1 minute timeframe for high leverage
    timeframe = '1m'
    can_short = True
    
    # 20% hard stop loss
    stoploss = -0.20
    
    # Disable trailing stop to strictly adhere to the 50/20 target
    trailing_stop = False

    # 50% take profit
    minimal_roi = {
        "0": 0.50
    }

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: str,
                 side: str, **kwargs) -> float:
        """
        Hardcoded leverage of 100.0 for OKX Futures
        """
        return 100.0

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        """
        Calculate indicators using TA-Lib
        """
        # Calculate RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        """
        Entry signals
        """
        # Long entry when RSI crosses below 30
        dataframe.loc[
            (
                (qtpylib.crossed_below(dataframe['rsi'], 30)) &
                (dataframe['volume'] > 0)
            ),
            ['enter_long', 'enter_tag']] = (1, 'rsi_oversold_long')
            
        # Short entry when RSI crosses above 70
        dataframe.loc[
            (
                (qtpylib.crossed_above(dataframe['rsi'], 70)) &
                (dataframe['volume'] > 0)
            ),
            ['enter_short', 'enter_tag']] = (1, 'rsi_overbought_short')

        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        """
        No explicit exit indicator, letting ROI and Trailing Stop/Stoploss handle it
        """
        return dataframe
