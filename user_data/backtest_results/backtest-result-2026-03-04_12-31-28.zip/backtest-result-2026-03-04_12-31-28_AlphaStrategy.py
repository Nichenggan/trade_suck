import numpy as np
import pandas as pd
from freqtrade.strategy import IStrategy
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib
from datetime import datetime

class AlphaStrategy(IStrategy):
    INTERFACE_VERSION = 3
    # 1 minute timeframe for high leverage
    timeframe = '1m'
    can_short = True
    
    # Tight 2% stop loss (With 100x leverage, if the price moves 2% against you, it's 200% loss technically. Freqtrade will trigger it)
    stoploss = -0.02
    
    # Trailing stop to lock in profits
    trailing_stop = True
    trailing_stop_positive = 0.01 # Activate trailing stop after 1% profit
    trailing_stop_positive_offset = 0.02 # Trail by 2%
    trailing_only_offset_is_reached = True

    # Initial target
    minimal_roi = {
        "0": 0.1,    # 10% profit immediately
        "10": 0.05,  # 5% profit after 10 mins
        "30": 0.01   # 1% profit after 30 mins
    }

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: str,
                 side: str, **kwargs) -> float:
        """
        Hardcoded leverage of 100.0 for OKX Futures
        """
        return 100.0

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        """
        Calculate indicators using TA-Lib
        """
        # Calculate RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        """
        Entry signals
        """
        # Long entry when RSI crosses below 30
        dataframe.loc[
            (
                (qtpylib.crossed_below(dataframe['rsi'], 30)) &
                (dataframe['volume'] > 0)
            ),
            ['enter_long', 'enter_tag']] = (1, 'rsi_oversold_long')
            
        # Short entry when RSI crosses above 70
        dataframe.loc[
            (
                (qtpylib.crossed_above(dataframe['rsi'], 70)) &
                (dataframe['volume'] > 0)
            ),
            ['enter_short', 'enter_tag']] = (1, 'rsi_overbought_short')

        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        """
        No explicit exit indicator, letting ROI and Trailing Stop/Stoploss handle it
        """
        return dataframe
